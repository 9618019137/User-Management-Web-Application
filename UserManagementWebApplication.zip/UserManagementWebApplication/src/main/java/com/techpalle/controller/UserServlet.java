package com.techpalle.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Set;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.techpalle.dao.UserDao;
import com.techpalle.model.User;

@WebServlet("/")
public class UserServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String path=request.getServletPath();
		switch(path) {
		case "/insert":
			insertUserData(request,response);
			break;
		
		case "/newForm":
			getNewFormPage(request,response);
			break;
		case "/edit":
			getEditForm(request,response);
		case "/update":
			updateUserData(request,response);
		case "/delete":
			deleteUserData(request,response);
		default:
			 getStratUppage(request,response);
			 break;
		}
	}
	private void deleteUserData(HttpServletRequest request, HttpServletResponse response) {
		// Read the id from url
		int id=Integer.parseInt(request.getParameter("id"));
		
		//Call jdbc code from dao
		UserDao.deleteUser(id);
		//Redirect User to user-list page
		getStratUppage(request, response);
		
	}
	private void updateUserData(HttpServletRequest request, HttpServletResponse response) {
		//Read the data in given browser
		int i=Integer.parseInt(request.getParameter("id"));
		String n=request.getParameter("name");
		String e=request.getParameter("email");
		String c=request.getParameter("country");
		//Store the above data in bean object
		User u=new User(i,n,e,c);
		//call the Dao [insertUser] method by passing bean object
		UserDao.updateUser(u);
		//Redirect User to user-list page
		getStratUppage(request, response);
		
		
	}
	private void getEditForm(HttpServletRequest request, HttpServletResponse response) {
		
		try {
			//Read the id from database
			int i= Integer.parseInt(request.getParameter("id")) ;
			User user= UserDao.getUserById(i);
			request.setAttribute("u", user);
			// Redirect User to form page
			RequestDispatcher rd=request.getRequestDispatcher("user-form.jsp");
			rd.forward(request, response);
		} catch (ServletException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}
	private void insertUserData(HttpServletRequest request, HttpServletResponse response) {
		//Read The data from Browser 
		String n=request.getParameter("name");
		String e=request.getParameter("email");
		String c=request.getParameter("country");
        //Store the above data in Bean Class
		User user=new User(n,e,c);
		//call the Dao [insertUser] method by passing bean object
		UserDao.insertUser(user);
		
		//Redirect User to user-list page
		getStratUppage(request, response);
		
	}
	private void getNewFormPage(HttpServletRequest request, HttpServletResponse response) {
		//Redirect User to Startup[user-form.jsp] page
		try {
			RequestDispatcher rd=request.getRequestDispatcher("user-form.jsp");
			rd.forward(request, response);
		} catch (ServletException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	private void getStratUppage(HttpServletRequest request, HttpServletResponse response) {
		//Redirect User to Startup[user-list.jsp] page
		
		try {
			//call dao methods which return all the user data 
			ArrayList<User> alUser=UserDao.displayAllUser();
			
			// send the above collection to jsp page
			request.setAttribute("User", alUser);
			
			RequestDispatcher rd=request.getRequestDispatcher("user-list.jsp");
			rd.forward(request, response);
		} catch (ServletException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		doGet(request, response);
	}

}
